--
-- PostgreSQL database dump
--

\restrict xa0xkmBQW3vcgCJIeTaa7yzc4eS5zfksvpyazqHJhIzyx0uPApefyNInobqdfgh

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_links; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.auth_links (
    id uuid NOT NULL,
    phone character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    data json,
    used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.auth_links OWNER TO yatedene;

--
-- Name: comptes; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.comptes (
    id uuid NOT NULL,
    user_id bigint,
    solde numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    devise character varying(10) DEFAULT 'XOF'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.comptes OWNER TO yatedene;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO yatedene;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: yatedene
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO yatedene;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yatedene
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO yatedene;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: yatedene
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO yatedene;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yatedene
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.oauth_access_tokens (
    id character varying(100) NOT NULL,
    user_id bigint,
    client_id bigint NOT NULL,
    name character varying(255),
    scopes text,
    revoked boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_access_tokens OWNER TO yatedene;

--
-- Name: oauth_auth_codes; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.oauth_auth_codes (
    id character varying(100) NOT NULL,
    user_id bigint NOT NULL,
    client_id bigint NOT NULL,
    scopes text,
    revoked boolean NOT NULL,
    expires_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_auth_codes OWNER TO yatedene;

--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.oauth_clients (
    id bigint NOT NULL,
    user_id bigint,
    name character varying(255) NOT NULL,
    secret character varying(100),
    provider character varying(255),
    redirect text NOT NULL,
    personal_access_client boolean NOT NULL,
    password_client boolean NOT NULL,
    revoked boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_clients OWNER TO yatedene;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: yatedene
--

CREATE SEQUENCE public.oauth_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth_clients_id_seq OWNER TO yatedene;

--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yatedene
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oauth_personal_access_clients; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.oauth_personal_access_clients (
    id bigint NOT NULL,
    client_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_personal_access_clients OWNER TO yatedene;

--
-- Name: oauth_personal_access_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: yatedene
--

CREATE SEQUENCE public.oauth_personal_access_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.oauth_personal_access_clients_id_seq OWNER TO yatedene;

--
-- Name: oauth_personal_access_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yatedene
--

ALTER SEQUENCE public.oauth_personal_access_clients_id_seq OWNED BY public.oauth_personal_access_clients.id;


--
-- Name: oauth_refresh_tokens; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.oauth_refresh_tokens (
    id character varying(100) NOT NULL,
    access_token_id character varying(100) NOT NULL,
    revoked boolean NOT NULL,
    expires_at timestamp(0) without time zone
);


ALTER TABLE public.oauth_refresh_tokens OWNER TO yatedene;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO yatedene;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO yatedene;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: yatedene
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO yatedene;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yatedene
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: qr_codes; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.qr_codes (
    id uuid NOT NULL,
    user_id bigint,
    code character varying(255) NOT NULL,
    meta json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.qr_codes OWNER TO yatedene;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.transactions (
    id uuid NOT NULL,
    compte_id uuid,
    type character varying(255) NOT NULL,
    montant numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    counterparty character varying(255),
    metadata jsonb,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    created_by bigint
);


ALTER TABLE public.transactions OWNER TO yatedene;

--
-- Name: users; Type: TABLE; Schema: public; Owner: yatedene
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    phone character varying(255),
    phone_verified_at timestamp(0) without time zone,
    is_phone_verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO yatedene;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: yatedene
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO yatedene;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: yatedene
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oauth_personal_access_clients id; Type: DEFAULT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_personal_access_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_personal_access_clients_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: auth_links; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.auth_links (id, phone, token, data, used_at, expires_at, created_at, updated_at) FROM stdin;
53462e51-f96c-467f-98c3-997f47f20ece	+221700000000	4Fmh9UxiH4He9YvO2hpcKWpCeTBZTVLCnJkiMPDNxNjAf3yV	{"redirect":"http:\\/\\/localhost"}	\N	2025-11-11 18:26:55	2025-11-10 18:26:55	2025-11-10 18:26:55
\.


--
-- Data for Name: comptes; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.comptes (id, user_id, solde, devise, created_at, updated_at) FROM stdin;
8b6a456e-66c9-4530-abb7-feec09c78937	3	2000.00	XOF	2025-11-10 18:26:55	2025-11-10 18:26:55
3f18b104-9e9d-4cff-b1ba-fbd94297d4c0	2	1100.00	XOF	2025-11-10 18:26:55	2025-11-10 18:42:43
df6acdab-4239-4cbd-aac0-6a73e01ce2ef	1	150.00	XOF	2025-11-10 18:41:50	2025-11-10 18:44:14
114db523-3afd-4825-b6a1-a5f901935a93	4	3250.00	XOF	2025-11-10 18:26:55	2025-11-10 18:44:14
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2016_06_01_000001_create_oauth_auth_codes_table	1
4	2016_06_01_000002_create_oauth_access_tokens_table	1
5	2016_06_01_000003_create_oauth_refresh_tokens_table	1
6	2016_06_01_000004_create_oauth_clients_table	1
7	2016_06_01_000005_create_oauth_personal_access_clients_table	1
8	2019_08_19_000000_create_failed_jobs_table	1
9	2019_12_14_000001_create_personal_access_tokens_table	1
10	2025_11_10_000001_create_auth_links_table	1
11	2025_11_10_000002_create_comptes_table	1
12	2025_11_10_000003_create_transactions_table	1
13	2025_11_10_000010_add_phone_to_users	1
14	2025_11_10_000011_fix_transactions_created_by	1
15	2025_11_10_000012_add_is_phone_verified_to_users	1
16	2025_11_10_000013_create_qr_codes_table	1
17	2025_11_11_000000_rename_fields_to_french	1
18	2025_11_12_000000_add_french_fields	1
19	2025_11_13_000000_drop_legacy_fields	2
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.oauth_access_tokens (id, user_id, client_id, name, scopes, revoked, created_at, updated_at, expires_at) FROM stdin;
520400f0fe192f0b558621942a873b221ee6efda32c9008f9f6fc38df355b357fcc7e931b490d56b	1	1	dev-token	[]	f	2025-11-10 18:30:59	2025-11-10 18:30:59	2026-11-10 18:30:59
a1901aa1ed4ec80c38df9b4bd963423c60fb1642b61c15087f3dc85263be6d6c835864a2b88ce650	1	1	dev-token	[]	f	2025-11-10 18:40:06	2025-11-10 18:40:06	2026-11-10 18:40:06
5e67d8f8caeccee52e3fb4a3f4a03a8c8305adb4c2e15805d412c3981850652eb6406ed27a5db919	1	1	dev-token	[]	f	2025-11-10 18:41:02	2025-11-10 18:41:02	2026-11-10 18:41:02
\.


--
-- Data for Name: oauth_auth_codes; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.oauth_auth_codes (id, user_id, client_id, scopes, revoked, expires_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.oauth_clients (id, user_id, name, secret, provider, redirect, personal_access_client, password_client, revoked, created_at, updated_at) FROM stdin;
1	\N	Laravel Personal Access Client	dj80Ig6wwW6dtNzeQiKvJneV0YRynl99LfhqPKEn	\N	http://localhost	t	f	f	2025-11-10 18:30:46	2025-11-10 18:30:46
2	\N	Laravel Password Grant Client	o5mVzkd2zwywvjai4bKUiTjwYYO27gmtywMcx5ji	users	http://localhost	f	t	f	2025-11-10 18:30:46	2025-11-10 18:30:46
\.


--
-- Data for Name: oauth_personal_access_clients; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.oauth_personal_access_clients (id, client_id, created_at, updated_at) FROM stdin;
1	1	2025-11-10 18:30:46	2025-11-10 18:30:46
\.


--
-- Data for Name: oauth_refresh_tokens; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.oauth_refresh_tokens (id, access_token_id, revoked, expires_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: qr_codes; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.qr_codes (id, user_id, code, meta, created_at, updated_at) FROM stdin;
dd833b8f-e8b7-46a6-b576-29858ff20b67	4	SEED-SHOP-QR-1762799215	{"code_marchand":"SHOP01","montant":250}	2025-11-10 18:26:55	2025-11-10 18:26:55
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.transactions (id, compte_id, type, montant, status, counterparty, metadata, created_at, updated_at, created_by) FROM stdin;
6c30575f-a156-4a36-a67d-188369cb85c9	df6acdab-4239-4cbd-aac0-6a73e01ce2ef	depot	500.00	completed	\N	\N	2025-11-10 18:42:19	2025-11-10 18:42:19	1
20d3167c-cd99-4bba-97f5-3dbbf74b91bb	df6acdab-4239-4cbd-aac0-6a73e01ce2ef	transfert_debit	100.00	completed	3f18b104-9e9d-4cff-b1ba-fbd94297d4c0	\N	2025-11-10 18:42:43	2025-11-10 18:42:43	1
167cc105-e0f5-4c8d-9621-ef46dd8d7e00	3f18b104-9e9d-4cff-b1ba-fbd94297d4c0	transfert_credit	100.00	completed	df6acdab-4239-4cbd-aac0-6a73e01ce2ef	\N	2025-11-10 18:42:43	2025-11-10 18:42:43	1
a68514bb-6f54-42fe-a571-b76df56066fe	df6acdab-4239-4cbd-aac0-6a73e01ce2ef	transfert_debit	250.00	completed	114db523-3afd-4825-b6a1-a5f901935a93	\N	2025-11-10 18:44:14	2025-11-10 18:44:14	1
7b6157a2-3aaa-498c-8012-b7ed40aa5a7a	114db523-3afd-4825-b6a1-a5f901935a93	transfert_credit	250.00	completed	df6acdab-4239-4cbd-aac0-6a73e01ce2ef	\N	2025-11-10 18:44:14	2025-11-10 18:44:14	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: yatedene
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, phone, phone_verified_at, is_phone_verified) FROM stdin;
1	Demo User	qgutmann@example.com	2025-11-10 18:26:55	$2y$12$xC68Lo6SevKdPLOxTm9MXOix11SKdnthjV68dKnw.vruTma7aYDGC	PFeOnQgs0y	2025-11-10 18:26:55	2025-11-10 18:26:55	+221700000001	\N	f
2	Alice	alice@example.local	\N	$2y$12$8ufOB2KOjSDP7aYMSsHNaecxGUn/h2/O18Yo9VLgUd6CXr5uDj.ZS	\N	2025-11-10 18:26:55	2025-11-10 18:26:55	+221700000002	\N	f
3	Bob	bob@example.local	\N	$2y$12$Ynw4EGXHo1mrJJZZgCMGbev8UhmdxrvOx7RX.hnyD/lOZdqr60.AC	\N	2025-11-10 18:26:55	2025-11-10 18:26:55	+221700000003	\N	f
4	Shop	shop@example.local	\N	$2y$12$nFzukoC5iDwThj1cZukMEeZhyXMIBqn7LNsn2GdkcjHQuE8C5Pa5i	\N	2025-11-10 18:26:55	2025-11-10 18:26:55	+221700000004	\N	f
\.


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yatedene
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yatedene
--

SELECT pg_catalog.setval('public.migrations_id_seq', 19, true);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yatedene
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 2, true);


--
-- Name: oauth_personal_access_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yatedene
--

SELECT pg_catalog.setval('public.oauth_personal_access_clients_id_seq', 1, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yatedene
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: yatedene
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: auth_links auth_links_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.auth_links
    ADD CONSTRAINT auth_links_pkey PRIMARY KEY (id);


--
-- Name: auth_links auth_links_token_unique; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.auth_links
    ADD CONSTRAINT auth_links_token_unique UNIQUE (token);


--
-- Name: comptes comptes_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.comptes
    ADD CONSTRAINT comptes_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_auth_codes oauth_auth_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_auth_codes
    ADD CONSTRAINT oauth_auth_codes_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_personal_access_clients oauth_personal_access_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_personal_access_clients
    ADD CONSTRAINT oauth_personal_access_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_refresh_tokens oauth_refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.oauth_refresh_tokens
    ADD CONSTRAINT oauth_refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: qr_codes qr_codes_code_unique; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_code_unique UNIQUE (code);


--
-- Name: qr_codes qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_phone_unique; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_unique UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: auth_links_phone_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX auth_links_phone_index ON public.auth_links USING btree (phone);


--
-- Name: comptes_user_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX comptes_user_id_index ON public.comptes USING btree (user_id);


--
-- Name: oauth_access_tokens_user_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX oauth_access_tokens_user_id_index ON public.oauth_access_tokens USING btree (user_id);


--
-- Name: oauth_auth_codes_user_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX oauth_auth_codes_user_id_index ON public.oauth_auth_codes USING btree (user_id);


--
-- Name: oauth_clients_user_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX oauth_clients_user_id_index ON public.oauth_clients USING btree (user_id);


--
-- Name: oauth_refresh_tokens_access_token_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX oauth_refresh_tokens_access_token_id_index ON public.oauth_refresh_tokens USING btree (access_token_id);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: transactions_compte_id_index; Type: INDEX; Schema: public; Owner: yatedene
--

CREATE INDEX transactions_compte_id_index ON public.transactions USING btree (compte_id);


--
-- Name: comptes comptes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.comptes
    ADD CONSTRAINT comptes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: qr_codes qr_codes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.qr_codes
    ADD CONSTRAINT qr_codes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_compte_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_compte_id_foreign FOREIGN KEY (compte_id) REFERENCES public.comptes(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: yatedene
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict xa0xkmBQW3vcgCJIeTaa7yzc4eS5zfksvpyazqHJhIzyx0uPApefyNInobqdfgh

